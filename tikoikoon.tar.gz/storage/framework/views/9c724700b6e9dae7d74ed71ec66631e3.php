<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-8">
    <h1 class="text-2xl font-bold mb-6"><?php echo e($event->name); ?></h1>
    <div class="flex flex-col md:flex-row gap-8">
        <div>
            <?php if($event->poster): ?>
                <img src="<?php echo e(asset('storage/' . $event->poster)); ?>" alt="Poster" class="w-96 h-96 object-cover rounded shadow" />
            <?php else: ?>
                <span class="text-gray-500">No poster available</span>
            <?php endif; ?>
        </div>
        <div class="flex-1">
            <p><strong>Date:</strong> <?php echo e($event->date); ?></p>
            <p><strong>Location:</strong> <?php echo e($event->location); ?></p>
            <p><strong>Manager:</strong> <?php echo e($event->manager ? $event->manager->name : 'Not assigned'); ?></p>
            <p><strong>Description:</strong> <?php echo e($event->description); ?></p>
            <p><strong>Packages:</strong></p>
            <ul class="list-disc ml-6">
                <?php $__currentLoopData = $event->packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($package->name); ?> - <?php echo e($package->price); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <a href="<?php echo e(route('admin.events.pdf', $event)); ?>" class="bg-green-500 text-white px-4 py-2 rounded mt-4 inline-block">Download PDF (1080x1080)</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/code-spectre/LoveLab-/resources/views/admin/events/show.blade.php ENDPATH**/ ?>